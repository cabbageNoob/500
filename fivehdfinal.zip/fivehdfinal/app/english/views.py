from flask import render_template,flash
from . import english
from .forms import NameForm
from ..models import English

@english.route('/eng', methods=['GET', 'POST'])
def engQuery():
    print('english graph')
    form = NameForm()
    if form.validate_on_submit():
        flash('查询结果呢？')
        words= English.query.filter_by(english=form.name.data).first()
        if words is not None:
            flash('查到了%s'%words)
        else:
            flash('没有这个单词呀！')
    return render_template('english/eng.html',form=form)


@english.route('/engHist', methods=['GET', 'POST'])
def hist():
    print('English Hist……')
    form = NameForm()
    str=chr(97)
    #wcount= English.query.filter(English.english.like('a%')).count()
    wordcount=[]
    for i in range(0,25):
        #print(chr(97+i))
        str=chr(97+i)
        wcount = English.query.filter(English.english.like(''+str+'%')).count()
        if wcount is not None:
            #flash('查到了%s'%wcount)
            wordcount.append(wcount)
        else:
            flash('没有这个单词呀！')

    return render_template('english/hist.html',wordcount=wordcount)

@english.route('/music', methods=['GET', 'POST'])
def histMusic():
    return render_template('english/histMusic.html')


from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import UserMixin
from . import db, login_manager


class Role(db.Model):
    __tablename__ = 'roles'
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(64), unique=True)
    users = db.relationship('User', backref='role', lazy='dynamic')

    def __repr__(self):
        return '<Role %r>' % self.name


class User(UserMixin, db.Model):
    __tablename__ = 'users'
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(64), unique=True, index=True)
    username = db.Column(db.String(64), unique=True, index=True)
    role_id = db.Column(db.Integer, db.ForeignKey('roles.id'))
    password_hash = db.Column(db.String(128))

    @property
    def password(self):
        raise AttributeError('password is not a readable attribute')

    @password.setter
    def password(self, password):
        self.password_hash = generate_password_hash(password)

    def verify_password(self, password):
        return check_password_hash(self.password_hash, password)

    def __repr__(self):
        return '<User %r>' % self.username

class English(db.Model):
    __tabel__='english'
    id = db.Column(db.Integer, primary_key=True)
    english = db.Column(db.String(15), unique=True, index=True)
    pt = db.Column(db.String(36))
    chinese= db.Column(db.String(41))
    flag= db.Column(db.String(1))

    def __repr__(self):
        return '<English %r>' % self.chinese

class Fivehd(db.Model):
    __tablename__='fivehd'
    id = db.Column(db.Integer, primary_key=True)
    year=db.Column(db.Integer)
    ranking=db.Column(db.Integer)
    lastyearRank=db.Column(db.Integer,nullable=True)
    companyName=db.Column(db.String(64))
    income=db.Column(db.Float)
    profit=db.Column(db.Float,nullable=True)
    country=db.Column(db.String(64))

    def __repr__(self):
        return ' %d年  排名:%d  %s  营业额:%f  国家:%s' % (self.year,self.ranking,self.companyName,self.income,self.country)
        #return '<500强 %s   %s>'% (self.companyName,self.country)
        #return '<500强 %s>' % self.country

class Distinct(db.Model):
    __tablename__='distinct'
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer)
    ranking = db.Column(db.Integer)
    industryName = db.Column(db.String(64), nullable=True)
    companyCount = db.Column(db.Integer)

    def __repr__(self):
        return '<行业500强 %s>'% self.industryName

class PeryearCount(db.Model):
    __tablename__='peryearCount'
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer)
    country = db.Column(db.String(64), nullable=True)
    count = db.Column(db.Integer)

    def __repr__(self):
        return '<%d年%s入围行业500强个数%d>'% (self.year,self.country,self.count)

class Year(db.Model):
    __tablename__='year'
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer)
    country = db.Column(db.String(64), nullable=True)
    countCountry = db.Column(db.Integer)

    def __repr__(self):
        return '<%d年%s入围行业500强个数%d>'% (self.year,self.country,self.countCountry)

class Country(db.Model):
    __tablename__='country'
    id = db.Column(db.Integer, primary_key=True)
    year = db.Column(db.Integer)
    country_name = db.Column(db.String(64), nullable=True)
    countCountry = db.Column(db.Integer)

    def __repr__(self):
        return '<%d年%s入围行业500强个数%d>'% (self.year,self.country_name,self.countCountry)
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


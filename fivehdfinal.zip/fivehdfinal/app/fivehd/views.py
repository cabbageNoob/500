from flask import render_template,flash
from . import fivehd
from .forms import NameForm
from ..models import Fivehd
from ..models import Distinct
from ..models import PeryearCount
from ..models import Year
from ..models import Country
@fivehd.route('/five', methods=['GET', 'POST'])
def fiveQuery():
    form = NameForm()
    if form.validate_on_submit():
        id= Fivehd.query.filter_by(year=form.year.data,ranking=form.ranking.data).first()
        if id is not None:
            flash('查到了%s'%id)
        else:
            flash('没有这个id呀！')
    return render_template('fivehd/fiveQuery.html',form=form)


@fivehd.route('/fiveHist', methods=['GET', 'POST'])
def fivehist():
    #wcount= Fivehd.query.filter(Fivehd.year==2017,Fivehd.country=='中国').count()

    countries=[]
    count=[]
    for year in range(2009,2019):
        country = Year.query.filter(Year.year == year).all()
        countries_year=[]
        count_year=[]
        for i in range(0, 33):
            countries_year.append(country[i].country)
            ccount = country[i].countCountry
            if ccount is not None:
                count_year.append(ccount)
        countries.append(countries_year)
        count.append(count_year)
    return render_template('fivehd/fiveHist.html',countries=countries,count=count)

# @english.route('/music', methods=['GET', 'POST'])
# def histMusic():
#     return render_template('english/histMusic.html')

@fivehd.route('/rankChange', methods=['GET', 'POST'])
def rankChange():
    country_name=['中国','丹麦','以色列','俄罗斯','加拿大','匈牙利','卢森堡','印度','印度尼西亚','哥伦比亚','土耳其','墨西哥','奥地利','委内瑞拉','巴西','德国','意大利','挪威','新加坡','日本','智利','比利时','比利时/荷兰','沙特阿拉伯','法国','波兰','泰国','澳大利亚','爱尔兰','瑞典','瑞士','美国','芬兰','英国','英国/荷兰','荷兰','葡萄牙','西班牙','阿拉伯联合酋长国','韩国','马来西亚']
    datasets=[]
    for countryName in country_name:
        data=Country.query.filter(Country.country_name==countryName).all()
        datas=[0,0,0,0,0,0,0,0,0,0]
        i=0
        for j in range(0,len(data)):
            if data[j].year == j+2009:
                datas[j]=data[j].countCountry
            else:
                pass

        # for year in range(2009,2019):
        #     if data[i].year==year:
        #         datacount = data[i].countCountry
        #     else:
        #         datacount=0
            # datacount=Country.query.filter(Country.country_name==countryName,Country.year==year).all()
            # print(datacount)
            # datacount=datacount[0].countCountry
            # dataset.append(datas)
            # i+=1
        datasets.append(datas)
    return render_template('fivehd/rankChange.html',datasets=datasets)


@fivehd.route('/industry', methods=['GET', 'POST'])
def industry():
    datas=[]
    for year in range(2012,2019):
        data=Distinct.query.filter(Distinct.year==year).all()
        datas.append(data)
    return render_template('fivehd/industry.html',dataset=datas)


@fivehd.route('/peryearCount', methods=['GET', 'POST'])
def peryearCount():
    datas=PeryearCount.query.filter().all()
    return render_template('fivehd/peryearCount.html',dataset=datas)

@fivehd.route('/difference', methods=['GET', 'POST'])
def difference():
    dataset0=[]
    dataset1=[]
    dataset2 = []
    dataset3 = []
    dataset4 = []
    dataset5 = []
    dataset=[]
    # flash(data)
    for i in range(2009,2019):
        datacount0=Fivehd.query.filter(Fivehd.country=='中国',Fivehd.year==i).count()
        datacount1 =Fivehd.query.filter(Fivehd.country == '美国', Fivehd.year == i).count()
        datacount2 = Fivehd.query.filter(Fivehd.country == '日本', Fivehd.year == i).count()
        datacount3 = Fivehd.query.filter(Fivehd.country == '德国', Fivehd.year == i).count()
        datacount4 = Fivehd.query.filter(Fivehd.country == '法国', Fivehd.year == i).count()
        datacount5 = Fivehd.query.filter(Fivehd.country == '英国', Fivehd.year == i).count()
        dataset0.append(datacount0)
        dataset1.append(datacount1)
        dataset2.append(datacount2)
        dataset3.append(datacount3)
        dataset4.append(datacount4)
        dataset5.append(datacount5)
    dataset=[dataset0,dataset1,dataset2,dataset3,dataset4,dataset5]
    datas = PeryearCount.query.filter().all()
    return render_template('fivehd/difference.html',dataset=dataset)

@fivehd.route('/worldmap', methods=['GET', 'POST'])
def worldmap():
    datas=Year.query.filter(Year.year==2018).all()
    # flash(datas)
    return render_template('fivehd/worldmap.html',datas=datas)

@fivehd.route('/WCloud', methods=['GET', 'POST'])
def wcloud():
    datas=PeryearCount.query.filter().all()
    return render_template('fivehd/wordcloud.html')

@fivehd.route('/word1', methods=['GET', 'POST'])
def word1():
    datas=PeryearCount.query.filter().all()
    return render_template('fivehd/WCloud/wordcloud1.html')

@fivehd.route('/word2', methods=['GET', 'POST'])
def word2():
    datas=PeryearCount.query.filter().all()
    return render_template('fivehd/WCloud/wordcloud2.html')

@fivehd.route('/barGraph', methods=['GET', 'POST'])
def barGraph():
    datas=PeryearCount.query.filter().all()
    return render_template('fivehd/bargraph/bargraph.html')

@fivehd.route('/chinaBaidumap', methods=['GET', 'POST'])
def chinaBaidumap():
    datas=PeryearCount.query.filter().all()
    return render_template('fivehd/chinaBaidumap.html')
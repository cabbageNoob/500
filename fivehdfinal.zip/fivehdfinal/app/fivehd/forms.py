from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired


class NameForm(FlaskForm):
    year = StringField('输入年份', validators=[DataRequired()])
    ranking = StringField('输入排名', validators=[DataRequired()])
    submit = SubmitField('查询')

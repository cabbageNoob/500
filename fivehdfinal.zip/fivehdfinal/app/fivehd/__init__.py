from flask import Blueprint

fivehd = Blueprint('fivehd', __name__)

from . import views